package javamodularity.easytext;

import java.util.List;
import java.util.LinkedList;

public class Main {
	public static void main(String[] args) {
		List<String> list = new LinkedList<>();
		list.add("One");
		list.add("Two");
		System.out.println("list");
		System.out.println(list);
	}
}
