module easytext.gui {
	requires java.desktop;
	requires easytext.analysis;	
}
