module easytext.gui {
	requires java.desktop;
	requires easytext.analysis.api;
	uses javamodularity.easytext.analysis.api.Analyzer;
}
