package javamodularity.easytext.analysis.internal;

public class SyllableCounter {
	public int getCount() {
		return 0;
	}
}
