package javamodularity.easytext.analysis.api;


public interface Analyzer {
	public int getCount();
	public String getName();
}
