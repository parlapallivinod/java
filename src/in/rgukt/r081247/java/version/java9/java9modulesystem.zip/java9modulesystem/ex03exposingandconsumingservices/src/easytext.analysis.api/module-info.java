module easytext.analysis.api {
	exports javamodularity.easytext.analysis.api;
}
