package javamodularity.easytext.analysis;


public interface Analyzer {
	public int getCount();
	public String getName();
}
